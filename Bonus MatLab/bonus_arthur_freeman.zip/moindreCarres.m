function eps = moindreCarres(Mexp, Mth, t_final)
    res = 0;
    for t = 1:t_final
       res =  res + (Mexp(t) - Mth(t) )^2;
    end
    eps = res;
end