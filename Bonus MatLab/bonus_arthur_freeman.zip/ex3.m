import evolution.evolution.*; %On importe la fonction evolution du fichier evolution.m
import moindreCarres.moindreCarres.*;

ex3bonus()

function ex3bonus()
    %Donnees est variable obtenue en faisant import data du fichier .dat en
    %matrice.
    donnees = importdata('grippedata.dat');
    Mexp = donnees'; %Je travaille en vecteurs lignes.
        
    t=[0:1:48];
    
    %On affiche les valeurs exp?rimentales. 
    figure;
    plot(t, Mexp, 'o'); title('Malades experimentaux en fonction du temps'); xlabel('t'); ylabel('Mexp(t)');
    hold on;
    
    t_final = 48; b = 4; D = 0.28; P = 0.2; 
    
    N = 157759; R0 = 0; M0 = 3; S0 = N - M0;
    
    [Sth,Mth,Rth] = evolution(t_final, D, 4, S0, M0, R0);
    
    plot(t, Mth); title('Malades en fonction du temps'); xlabel('t'); ylabel('M(t)');
    
    disp("L'erreur est: ");
    err = moindreCarres(Mexp, Mth, t_final)
    
    
    disp("Calculons une approximation de la valeur de b:");
    
    b_app = 2;    
    while err > 1.69e+05
        b_app = b_app + 0.01;
        if b_app < 5
            [Sth,Mth,Rth] = evolution(t_final, D, b_app, S0, M0, R0);
            err = moindreCarres(Mexp, Mth, t_final);       
        else
            break
        end
    end
    disp(b_app);
    plot(t, Mth); 
    legend('val experimentales ', 'b = 4',strcat('b = ', num2str(b_app) )  )
    
end