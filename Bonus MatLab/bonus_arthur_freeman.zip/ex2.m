%Ex 2.) ?pid?mologie de la grippe aux USA.

import evolution.evolution.*; %On importe la fonction evolution du fichier evolution.m

ex2bonus();

function ex2bonus()
    S0 = 157756; M0 = 3; R0 = 0; %Param?tres initiaux.
    t_i = 0; t_final = 48;
    
    %Ex 2.2.) Param?tres fournis.
    D = 0.28;
    b = 4;
    
    %Fonction ?volution qui renvoie les sains, malades et r?tablis.
    [S,M,R] = evolution(t_final, D, b, S0, M0, R0); 
    
    t = [t_i:1:t_final];
    %Je nomme mes axes pour l'?sth?tique.
    plot(t, S); title('Sains en fonction du temps'); xlabel('t'); ylabel('S(t)');
    figure;
    plot(t, R); title('R?tablis en fonction du temps'); xlabel('t'); ylabel('R(t)');
    figure;
    plot(t, M); title('Malades en fonction du temps'); xlabel('t'); ylabel('M(t)');
end 