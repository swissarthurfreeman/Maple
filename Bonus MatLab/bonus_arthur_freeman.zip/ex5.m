ex5bonus()

function ex5bonus()
    N = 5000;
    M = rand(N);
    m = (M + M') / 2;
    [V,D] = eig(m);
    val_propres = diag(D)';
    val_propres(N) = [];
    disp(val_propres');
    disp("Num one");
    disp(val_propres(1));
    histogram(val_propres); 
end