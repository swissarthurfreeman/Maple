function ex1()
    v = ones(1,20);
    disp(v)
    M = diag(v,1)

    disp(M^21);
    %Elle est nilpotente pour n = 21!
    
    
    vl(1) = 0;
    for k=1:20
        vl(k+1) = 2*vl(k)+ 5;
    end
    disp(vl)
end